<?php $__env->startSection('title', 'TOPSIS | Detail Perhitungan'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>TOPSIS | Detail Perhitungan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
      <div class="card ">
          <div class="card-header ">
              <h4 class="card-title">Langkah Perhitungan TOPSIS</h4>
          </div>
          <div class="card-body ">
              <div class="row">
                  <div class="col-md-4">
                      <ul class="nav nav-pills nav-pills-primary flex-column" role="tablist">
                          <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#link4" role="tablist">
                                  1. Nilai Kriteria
                              </a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#link5" role="tablist">
                                  2. Membuat Matriks Keputusan
                              </a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#link6" role="tablist">
                                  3. Normalisasi Matriks
                              </a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#link7" role="tablist">
                                  4. Normalisasi Matriks * Bobot
                              </a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#link8" role="tablist">
                                  5. Menentukan Solusi Ideal Positif & Negatif
                              </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#link9" role="tablist">
                                6. Menghitung Nilai Preferensi & Melakukan Perankingan
                            </a>
                        </li>
                      </ul>
                  </div>
                  <div class="col-md-8">
                      <div class="tab-content">
                          <div class="tab-pane active" id="link4">
                              <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <p> 
                                  <button class="btn btn-primary btn-block text-left" type="button" data-toggle="collapse" data-target="#kriteria<?php echo e($k->id); ?>" aria-expanded="false" aria-controls="kriteria<?php echo e($k->id); ?>">
                                      <?php echo e($k->kode); ?>. <?php echo e($k->nama); ?> (<?php echo e($k->bobot * 100); ?>%) (<?php echo e($k->tipe); ?>)
                                  </button>
                              </p>
                              <div class="collapse" id="kriteria<?php echo e($k->id); ?>">
                                  <div class="card card-body">
                                      <div class="card">
                                          <div class="card-header">
                                              <h4 class="card-title"><?php echo e($k->kode); ?>. <?php echo e($k->nama); ?></h4>
                                          </div>
                                          <div class="card-body">
                                              <div class="table-responsive">
                                                  <table class="table">
                                                      <thead class="text-primary">
                                                          <tr>
                                                              <th>#</th>
                                                              <th><?php echo e($k->nama); ?></th>
                                                              
                                                              <th>Nilai</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody>
                                                          <?php $__currentLoopData = $k->subkriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <tr>
                                                                  <td><?php echo e($loop->iteration); ?></td>
                                                                  <td><?php echo e($sk->kondisi); ?></td>
                                                                  
                                                                  <td><?php echo e($sk->nilai); ?></td>
                                                              </tr>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </tbody>
                                                  </table>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                          <div class="tab-pane" id="link5">
                              <h5 class="text-primary">Membuat Matriks Keputusan :</h5>
                              <hr class="text-primary">
                              <div class="table-responsive">
                                  <table class="table">
                                      <thead class="text-white bg-primary">
                                          <tr>
                                              <th>#</th>
                                              <th>Alternatif</th>
                                              <th>C1</th>
                                              <th>C2</th>
                                              <th>C3</th>
                                              <th>C4</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                          <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                          <tr>
                                              <td>A<?php echo e($loop->iteration); ?></td>
                                              <td>(<?php echo e($p['no_ktp']); ?>) <?php echo e($p['nama']); ?></td>
                                              <td><?php echo e($p['O_C1']); ?></td>
                                              <td><?php echo e($p['O_C2']); ?></td>
                                              <td><?php echo e($p['O_C3']); ?></td>
                                              <td><?php echo e($p['O_C4']); ?></td>
                                          </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                              <tr>
                                                  <td colspan="8" class="text-center">Belum Ada Data</td>
                                              </tr>
                                          <?php endif; ?>
                                      </tbody>
                                  </table>
                              </div>
                          </div>
                          <div class="tab-pane" id="link6">
                            
                            
                              <h5 class="text-primary">Tabel Hasil Normalisasi :</h5>
                              <hr class="text-primary">
                              <div class="table-responsive">
                                <table class="table table-sm-responsive">
                                  <thead class="text-white bg-primary">
                                      <tr>
                                          <th>#</th>
                                          <th>Alternatif</th>
                                          <th>C1</th>
                                          <th>C2</th>
                                          <th>C3</th>
                                          <th>C4</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <tr>
                                          <td>A<?php echo e($loop->iteration); ?></td>
                                          <td>(<?php echo e($p['no_ktp']); ?>) <?php echo e($p['nama']); ?></td>
                                          <td><?php echo e($p['N_C1']); ?></td>
                                          <td><?php echo e($p['N_C2']); ?></td>
                                          <td><?php echo e($p['N_C3']); ?></td>
                                          <td><?php echo e($p['N_C4']); ?></td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                          <tr>
                                              <td colspan="8" class="text-center">Belum Ada Data</td>
                                          </tr>
                                      <?php endif; ?>
                                  </tbody>
                              </table>
                              </div>
                          </div>
                          <div class="tab-pane" id="link7">
                              
                              <h5 class="text-primary">Tabel Normalisasi * Bobot :</h5>
                              <div class="table-responsive">
                                <table class="table table-sm-responsive">
                                  <thead class="text-white bg-primary">
                                      <tr>
                                          <th>#</th>
                                          <th>Alternatif</th>
                                          <th>C1</th>
                                          <th>C2</th>
                                          <th>C3</th>
                                          <th>C4</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                      <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <tr>
                                          <td>A<?php echo e($loop->iteration); ?></td>
                                          <td>(<?php echo e($p['no_ktp']); ?>) <?php echo e($p['nama']); ?></td>
                                          <td><?php echo e($p['C1']); ?></td>
                                          <td><?php echo e($p['C2']); ?></td>
                                          <td><?php echo e($p['C3']); ?></td>
                                          <td><?php echo e($p['C4']); ?></td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                          <tr>
                                              <td colspan="8" class="text-center">Belum Ada Data</td>
                                          </tr>
                                      <?php endif; ?>
                                  </tbody>
                              </table>
                              </div>
                          </div>
                          <div class="tab-pane" id="link8">
                              <div class="table-responsive">
                                <h5 class="text-justify text-primary">Mencari nilai max dan min dari normalisasi berbobot, menggunakan metode perhitungan TOPSIS (Technique For Others Reference By Smilarity To Ideal Solution). </h5>
                                  <br> <small>Jika kriteria bersifat benefit (makin besar makin baik) maka V+ =Max dan V- = Min</small>
                                  <br><small>Jika kriteria bersifat Cost (makin kecil makin baik) maka V+ =Min dan V- = Max</small>
                                <table class="table table-md-responsive">
                                    <tr class="text-center bg-light">
                                        <th rowspan="2"><strong>Alternatif</strong></th>
                                        <th colspan="6"><strong>Kriteria</strong></th>
                                    </tr>
                                    <tr class="bg-light">
                                        <th>C1</th>
                                        <th>C2</th>
                                        <th>C3</th>
                                        <th>C4</th>
                                    </tr>
                                    <tr>
                                        <td class="bg-light"><strong>MAX</strong></td>
                                        <td><?php echo e($bobot['perbaikan']['C1']['max']); ?></td>
                                        <td><?php echo e($bobot['perbaikan']['C2']['max']); ?></td>
                                        <td><?php echo e($bobot['perbaikan']['C3']['max']); ?></td>
                                        <td><?php echo e($bobot['perbaikan']['C4']['max']); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="bg-light"><strong>MIN</strong></td>
                                        <td><?php echo e($bobot['perbaikan']['C1']['min']); ?></td>
                                        <td><?php echo e($bobot['perbaikan']['C2']['min']); ?></td>
                                        <td><?php echo e($bobot['perbaikan']['C3']['min']); ?></td>
                                        <td><?php echo e($bobot['perbaikan']['C4']['min']); ?></td>
                                    </tr>
                                </table>
                                <h5 class="text-justify text-primary">
                                  Langkah ke-lima, Menentukan jarak tiap alternatif menggunakan metode TOPSIS (Technique For Others Reference By Smilarity To Ideal Solution). Mencari Nilai A_X+ :                            
                                </h5>
                                <hr class="text-primary">
      
                              <table class="table table-sm-responsive">
                                  <tr class="bg-light">
                                      <th><strong>Alternatif</strong></th>
                                      <th><strong>Perhitungan Nilai A<sup>+</sup> </strong></th>
                                      <th><strong>A<sup>+</sup> </strong></th>
                                  </tr>
                                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                          <td class="bg-light">A<?php echo e($loop->iteration); ?>+</td>    
                                          <td>√(<?php echo e($bobot['perbaikan']['C1']['max']); ?> - <?php echo e($item->C1); ?>)<sup>2</sup> + (<?php echo e($bobot['perbaikan']['C2']['max']); ?> - <?php echo e($item->C2); ?>)<sup>2</sup> + (<?php echo e($bobot['perbaikan']['C3']['max']); ?> - <?php echo e($item->C3); ?>)<sup>2</sup> + (<?php echo e($bobot['perbaikan']['C4']['max']); ?> - <?php echo e($item->C4); ?>)<sup>2</sup>)<sup>2</sup> + </td>    
                                          <td><?php echo e($item->A_max); ?></td>    
                                      </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <tr class="bg-light">
                                      <th><strong>Alternatif</strong></th>
                                      <th><strong>Perhitungan Nilai A<sup>-</sup> </strong></th>
                                      <th><strong>A<sup>-</sup> </strong></th>
                                  </tr>
                                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                          <td class="bg-light">A<?php echo e($loop->iteration); ?>+</td>    
                                          <td>√(<?php echo e($item->C1); ?> - <?php echo e($bobot['perbaikan']['C1']['min']); ?>)<sup>2</sup> + (<?php echo e($item->C2); ?> - <?php echo e($bobot['perbaikan']['C2']['min']); ?>)<sup>2</sup> + (<?php echo e($item->C3); ?> - <?php echo e($bobot['perbaikan']['C3']['min']); ?>)<sup>2</sup> + (<?php echo e($item->C4); ?> - <?php echo e($bobot['perbaikan']['C4']['min']); ?>)<sup>2</sup>)<sup>2</sup> + </td>    
                                          <td><?php echo e($item->A_min); ?></td>    
                                      </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </table>
                              <h5 class="text-justify">Sehingga di dapat :</h5>
                              <table class="table table-sm-responsive">
                                  <tr class="bg-light">
                                      <th colspan="4">
                                          <strong>Tabel nilai A<sup>+</sup> dan A<sup>-</sup> dari setiap Alternatif</strong>
                                      </th>
                                  </tr>
                                  <tr>
                                      <th colspan="2">
                                          <strong>A<sup>+</sup></strong>
                                      </th>
                                      <th colspan="2">
                                          <strong>A<sup>-</sup></strong>
                                      </th>
                                  </tr>
                                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td class="bg-light">A<?php echo e($loop->iteration); ?><sup>+</sup></td>
                                      <td><?php echo e($item->A_max); ?></td>
                                      <td class="bg-light">A<?php echo e($loop->iteration); ?><sup>-</sup></td>
                                      <td><?php echo e($item->A_min); ?></td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </table>
                              </div>
                          </div>
                          <div class="tab-pane" id="link9">
                            <h5 class="text-justify text-primary">Langkah ke-enam, menghitung nilai preferensi setiap alternatif terdekat dengan solusi ideal, menggunakan metode TOPSIS (Technique For Others Reference By Smilarity To Ideal Solution).
                            </h5>
                            <hr class="text-primary">
    
                            <table class="table table-sm-responsive">
                                <tr class="bg-light">
                                    <th><strong>Alternatif</strong></th>
                                    <th><strong>A<sup>-</sup> / (A<sup>-</sup> + A<sup>+</sup>)</strong></th>
                                    <th><strong>Nilai Preferensi</strong></th>
                                </tr>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="bg-light">A<?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->A_min); ?> / (<?php echo e($item->A_min); ?> + <?php echo e($item->A_max); ?>)</td>
                                    <td><?php echo e($item->preferensi); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
    
                            <table class="table table-sm-responsive">
                                <tr class="bg-light">
                                    <th colspan="4"><strong>Hasil Nilai Akhir Data Calon Penerima Bantuan</strong></th>
                                </tr>
                                <tr>
                                    <th><strong>Ranking</strong></th>
                                    <th ><strong>Alternatif</strong></th>
                                    <th><strong>Nilai</strong></th>
                                </tr>
                                <?php $__currentLoopData = $rank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="bg-light">(<?php echo e($item->no_ktp); ?>) <?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->preferensi); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                      </div>
                  </div>
              </div>                    
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    * { font: 17px Calibri; } 
    table { width: 70%; }
    table, th, td { border: solid 1px #DDD;
        border-collapse: collapse; padding: 2px 3px; text-align: center;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SPK-TOPSIS-Man\resources\views/topsis/detail.blade.php ENDPATH**/ ?>