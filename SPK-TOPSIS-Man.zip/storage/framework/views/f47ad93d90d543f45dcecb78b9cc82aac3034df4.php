<?php $__env->startSection('title', 'Daftar Pengguna'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Daftar Pengguna</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- Left col -->
  <section class="col-lg-12 connectedSortable">
    <div class="card direct-chat direct-chat-primary">
      <div class="card-header">
        <h3 class="card-title"> 
          Daftar Pengguna
          <span class="badge badge-primary"> <?php echo e($users->count()); ?></span>
        </h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
        </div>
      </div>
      <div class="card-body mx-2 my-2 px-2 py-2">
        <?php if(session('sukses')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <?php echo Session::get('sukses'); ?>

              </div>
            <?php endif; ?>
        <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Peran</th>
                <th>Email</th>
                <th>Opsi</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($item->name); ?></td>
              <?php if($item->role == 1): ?>
                <td>Admin</td> 
              <?php else: ?>
                <td>Pelamar</td> 
              <?php endif; ?>
              <td><?php echo e($item->email); ?></td>
              <td>
                <div class="btn-group">
                  <a href="<?php echo e(route('admin.password',$item->id)); ?>" class="btn btn-info">
                    <i class="fas fa-eye"></i>
                  </a>
                  <?php if($item->role == 1): ?>
                  <?php else: ?>
                  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-lg-<?php echo e($item->id); ?>">
                    <i class="fas fa-trash"></i>
                  </button>
                  <?php endif; ?>
                </div>

                <div class="modal fade" id="modal-lg-<?php echo e($item->id); ?>">
                  <div class="modal-dialog modal-md">
                    <div class="modal-content">
                      <div class="modal-header bg-danger">
                        <h5 class="modal-title"><i class="fas fa-trash"></i> Hapus Data <strong><?php echo e($item->name); ?></strong></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                        <form action="<?php echo e(route('admin.user.destroy',$item->id)); ?>"  method="POST" enctype="multipart/form-data">
                          <?php echo csrf_field(); ?>
                         
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Tidak</button>
                        <button type="submit" class="btn btn-danger">Hapus Data</button>
                      </form>
                      </div>
                    </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
              <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Peran</th>
                <th>Email</th>
                <th>Opsi</th>
              </tr>
            </tfoot>
          </table>
      </div>
    </div>
  </section>
  <!-- right col -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/datatables-plugins/responsive/css/responsive.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/datatables-plugins/buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.colVis.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script>
  $(function () {
    $("#example1").DataTable({
      "columnDefs": [
        { "width": "10%", "targets": 1 }
      ],
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SPK-TOPSIS-Man\resources\views/users/index.blade.php ENDPATH**/ ?>