<?php $__env->startSection('title', 'Daftar Kriteria'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Halaman Daftar Kriteria</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
      <div class="card ">
          <div class="card-header ">
              <h4 class="card-title">Daftar Kriteria</h4>
          </div>
          <div class="card-body ">
              <div class="row">
                  <div class="col-md-12">
                    <?php $__currentLoopData = $kriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p> 
                        <button class="btn btn-primary btn-block text-left" type="button" data-toggle="collapse" data-target="#kriteria<?php echo e($k->id); ?>" aria-expanded="false" aria-controls="kriteria<?php echo e($k->id); ?>">
                            <?php echo e($k->kode); ?>. <?php echo e($k->nama); ?> (<?php echo e($k->bobot * 100); ?>%) (<?php echo e($k->tipe); ?>)
                        </button>
                    </p>
                    <div class="collapse" id="kriteria<?php echo e($k->id); ?>">
                        <div class="card card-body">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title"><?php echo e($k->kode); ?>. <?php echo e($k->nama); ?></h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class="text-primary">
                                                <tr>
                                                    <th>#</th>
                                                    <th><?php echo e($k->nama); ?></th>
                                                    
                                                    <th>Nilai</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $k->subkriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($sk->kondisi); ?></td>
                                                        
                                                        <td><?php echo e($sk->nilai); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              </div>                    
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/datatables-plugins/responsive/css/responsive.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/datatables-plugins/buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.colVis.min.js')); ?>"></script>
<!-- AdminLTE App -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SPK-TOPSIS-Man\resources\views/kriteria/index.blade.php ENDPATH**/ ?>