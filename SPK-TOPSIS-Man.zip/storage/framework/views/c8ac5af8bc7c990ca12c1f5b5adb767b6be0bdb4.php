<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan Detail Pelamar <?php echo e($pendamping->nama_depan); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

</head>
<body>
  <style>
    #header,
    #footer {
      position: fixed;
      left: 0;
        right: 0;
        color: #aaa;
        font-size: 0.9em;
    }
    #header {
      top: 0;
        border-bottom: 0.1pt solid #aaa;
    }
    #footer {
      bottom: 0;
      border-top: 0.1pt solid #aaa;
    }
    .page-number:before {
        text-align: center;
        float: right;
        color: black;
      content: "PLN Samarinda | Hal " counter(page);
    }

    .page-break {
        page-break-after: always;
    }

    h1 {
        font-size: 40px;
    }

    h2 {
        font-size: 30px;
    }

    p {
        font-size: 12px;
        line-height:80%;
    }

    td{
      font-size: 10px;
      text-align: center;
      vertical-align: middle;
    }

    th{
      text-align: center;
    }
    .table > tbody > tr > td {
     vertical-align: middle;
    }
    </style>
<div>
  <div id="footer">
    <div class="page-number"></div>
  </div>
  <img src="<?php echo e($base64); ?>" width="100%" height="140"/>
  <table class="table table-sm table-borderless" style="border: white;">
    <thead class="mb-0">
      <tr>
        <th style="text-align: center; vertical-align: middle; font-size: 25px;" class="text-underline"><u>Laporan</u></th>
    </tr>
    <tr>
      <th style="text-align: center; vertical-align: middle;">Detail Informasi Pelamar</th>
    </tr>
    </thead>
  </table>
    <table class="table table-sm table-bordered">
        <thead style="font-size:10px;" class="thead-light">
          <tr>
            <th colspan="3" style="text-align: center; vertical-align: middle; font-size: 15px;"><span>Biodata Calon Pelamar</span></th>
          </tr>
          <tr>
            <td rowspan="10">
                  <img src="<?php echo e(url('public/pelamar/foto/'.$pendamping->foto)); ?>" class="mt-5 mb-0 px-0 py-0" alt="..." style="width: 100px; height: 120px;">
            </td>
            <th style="text-align: center; vertical-align: middle;">No. Ktp</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->no_ktp); ?></td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Nama</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->nama_depan.' '.$pendamping->nama_belakang); ?></td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Jenis Kelamin</th>
            <?php if($pendamping->jenis_kelamin == 1): ?>
              <td style="text-align: center; vertical-align: middle;">Pria</td>
            <?php else: ?>
              <td style="text-align: center; vertical-align: middle;">Wanita</td>
            <?php endif; ?>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">No HP</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->no_hp); ?></td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Email</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->email); ?></td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Tanggal Lahir</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->tanggal_lahir); ?></td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Umur</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->usia); ?> Tahun</td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Alamat</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->alamat); ?></td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Asal Sekolah</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->asal_sekolah); ?></td>
          </tr>
          <tr>
            <th style="text-align: center; vertical-align: middle;">Jurusan</th>
            <td style="text-align: center; vertical-align: middle;"><?php echo e($pendamping->jurusan); ?></td>
          </tr>
        </thead>
    </table>


        <table class="table table-borderless">
          <tbody>
            <tr>
              <td></td>
              <td></td>
              <td style="width: 150px;">Penanggung Jawab,</td>
            </tr>
            <tr>
              <td></td>
              <td></td>
              <td style="height: 20px; width: 150px;"></td>
            </tr>
            <tr>
              <td></td>
              <td ></td>
              <td style="width: 150px;"><u>..........................</u></td>
            </tr>
          </tbody>
        </table>

</div>
<script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\SPK-TOPSIS-Man\resources\views/laporan/pelamar.blade.php ENDPATH**/ ?>