<?php $__env->startSection('title', 'Admin | Ganti Password'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Admin | Ganti Password</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-3 col-12">
    <!-- Profile Image -->
    <div class="card card-primary card-outline">
      <div class="card-body box-profile">
        <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>
        <ul class="list-group list-group-unbordered mb-3">
          <li class="list-group-item">
            <b>Email</b> <div class="float-right"><?php echo e($user->email); ?></div>
          </li>
          <li class="list-group-item">
            <b>Peran</b> <div class="float-right"><?php if($user->role == 1): ?>
              Admin
          <?php else: ?>
              Calon Pendamping
          <?php endif; ?></div>
          </li>
        </ul>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  <!-- ./col -->
  <div class="col-lg-9 col-12">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title"><i class="fas fa-key"></i> Ganti Password</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <form action="<?php echo e(route('admin.ganti',$user->id)); ?>"  method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card-body">
          <div class="row">
            <div class="col-12">
              <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo implode('', $errors->all('<div>:message</div>')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                        <?php endif; ?>
              <?php if(session('error')): ?>
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <?php echo Session::get('error'); ?>

              </div>
            <?php endif; ?>
            <?php if(session('sukses')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <?php echo Session::get('sukses'); ?>

              </div>
            <?php endif; ?>
            </div>
            <div class="col">
              <div class="form-group">
                <label>Password Lama</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan Password Lama" value="<?php echo e(old('password')); ?>" required>
              </div>
            </div>
            <div class="col">
              <div class="form-group">
                <label>Password Baru</label>
                <input type="password" name="baru" class="form-control" placeholder="Masukkan Password Baru" value="<?php echo e(old('baru')); ?>" required>
              </div>
            </div>
          </div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer d-flex justify-content-end">
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
  <!-- ./col -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SPK-TOPSIS-Man\resources\views/users/show.blade.php ENDPATH**/ ?>